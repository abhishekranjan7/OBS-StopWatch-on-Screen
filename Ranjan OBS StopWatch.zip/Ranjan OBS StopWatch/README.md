# JS Stopwatch

This is simple JS stopwatch that uses [`setinterval`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/setInterval) to update the display of the clock.

## Quickstart
- Clone or download the project to your computer
- Open the project foolder
- Open `index.html` and you're all set

